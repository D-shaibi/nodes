#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def hello_world():
    text= rospy.Publisher('hello', String, queue_size= 10)
    rospy.init_node('greet', anonymous= False)
    stop= rospy.Rate(10)

    while not rospy.is_shutdown():
        message= 'Hello, World'
        rospy.loginfo(message)
        text.publish(message)
        stop.sleep()

if __name__ =='__main__':
    try:
        hello_world()
    except rospy.ROSInterruptException:
        pass



