#!/usr/bin/env python3

import rospy
from std_msgs.msg import String

def callback(data):
    rospy.loginfo(data.data)

def read_message():
    read= rospy.init_node('world', anonymous= False)
    rospy.Subscriber('hello',String, callback)
    rospy.spin()

if __name__ == '__main__':
    read_message()

